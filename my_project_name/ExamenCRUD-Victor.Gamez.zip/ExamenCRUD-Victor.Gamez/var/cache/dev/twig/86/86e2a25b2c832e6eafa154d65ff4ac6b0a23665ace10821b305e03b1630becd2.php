<?php

/* Producto/form.html.twig */
class __TwigTemplate_af1c894bb69e3d662ab433835980dc63c2e092914e68e66f1017cac38a049355 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/form.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f2abab48c3be62b5d520e3e3d374ff67769af7994ca6ed5e18b9ca6dbe50543 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f2abab48c3be62b5d520e3e3d374ff67769af7994ca6ed5e18b9ca6dbe50543->enter($__internal_8f2abab48c3be62b5d520e3e3d374ff67769af7994ca6ed5e18b9ca6dbe50543_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f2abab48c3be62b5d520e3e3d374ff67769af7994ca6ed5e18b9ca6dbe50543->leave($__internal_8f2abab48c3be62b5d520e3e3d374ff67769af7994ca6ed5e18b9ca6dbe50543_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a3478500480289f7b2a64897ce601c06c405250e8b39ab8386d442a1a40368da = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a3478500480289f7b2a64897ce601c06c405250e8b39ab8386d442a1a40368da->enter($__internal_a3478500480289f7b2a64897ce601c06c405250e8b39ab8386d442a1a40368da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/form.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_a3478500480289f7b2a64897ce601c06c405250e8b39ab8386d442a1a40368da->leave($__internal_a3478500480289f7b2a64897ce601c06c405250e8b39ab8386d442a1a40368da_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_ff7ec88ef47f392d8c30ecd83fc1ae0311c4ed1b0f4dd43b82116b25864d44f0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ff7ec88ef47f392d8c30ecd83fc1ae0311c4ed1b0f4dd43b82116b25864d44f0->enter($__internal_ff7ec88ef47f392d8c30ecd83fc1ae0311c4ed1b0f4dd43b82116b25864d44f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/form.html.twig"));

        // line 5
        echo "    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/producto_tabla.css"), "html", null, true);
        echo "\" />

    <div>
       <form method=\"post\" action=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo "\" novalidate=\"novalidate\">
           <div>

               ";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "value", array()));
        echo "

               <ul>
                   ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "errors", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
            // line 16
            echo "                        <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
            echo "</li>
                   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "               </ul>
           </div>
           <div>";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget');
        echo "</div>
           <div>";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'errors');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget');
        echo "</div>
           <div>";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'errors');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'widget');
        echo "</div>
           ";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "

           <div><input type=\"button\" value=\"Confirmar\"></div>



           <button value=\"CREATE\" id=\"boton\">
               <h1>Confirmar</h1>
           </button>

           <img id = \"imagen\"src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["gif"]) ? $context["gif"] : $this->getContext($context, "gif"))), "html", null, true);
        echo "\" />
       </form>
    </div>
";
        
        $__internal_ff7ec88ef47f392d8c30ecd83fc1ae0311c4ed1b0f4dd43b82116b25864d44f0->leave($__internal_ff7ec88ef47f392d8c30ecd83fc1ae0311c4ed1b0f4dd43b82116b25864d44f0_prof);

    }

    public function getTemplateName()
    {
        return "Producto/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 33,  116 => 23,  108 => 22,  100 => 21,  92 => 20,  88 => 18,  79 => 16,  75 => 15,  69 => 12,  63 => 9,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/producto_tabla.css') }}\" />

    <div>
       <form method=\"post\" action=\"{{ action }}\" novalidate=\"novalidate\">
           <div>

               {{ dump(form.vars.value) }}

               <ul>
                   {%  for error in form.vars.errors %}
                        <li>{{ error.message }}</li>
                   {% endfor %}
               </ul>
           </div>
           <div>{{ form_errors(form.name) }} {{ form_label(form.name) }}: {{ form_widget(form.name) }}</div>
           <div>{{ form_errors(form.description) }} {{ form_label(form.description) }}: {{ form_widget(form.description)  }}</div>
           <div>{{ form_errors(form.price) }} {{ form_label(form.price) }}: {{ form_widget(form.price) }}</div>
           {{ form_rest(form) }}

           <div><input type=\"button\" value=\"Confirmar\"></div>



           <button value=\"CREATE\" id=\"boton\">
               <h1>Confirmar</h1>
           </button>

           <img id = \"imagen\"src=\"{{ asset(gif) }}\" />
       </form>
    </div>
{% endblock %}
", "Producto/form.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/form.html.twig");
    }
}
