<?php

/* :CalculatorRacional:Index.html.twig */
class __TwigTemplate_83d685fb132edb0512851794136f536930d793fa4eb77a3e20fe34b572ef61aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":CalculatorRacional:Index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0ea4641a3d706364bc96e23aafb8131fafbcaaba295bcc5993afae3da31544c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0ea4641a3d706364bc96e23aafb8131fafbcaaba295bcc5993afae3da31544c9->enter($__internal_0ea4641a3d706364bc96e23aafb8131fafbcaaba295bcc5993afae3da31544c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":CalculatorRacional:Index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0ea4641a3d706364bc96e23aafb8131fafbcaaba295bcc5993afae3da31544c9->leave($__internal_0ea4641a3d706364bc96e23aafb8131fafbcaaba295bcc5993afae3da31544c9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_60ed6fbc31f7f893025e230f30b0ce4db0e595be448dfd97947a047a8bb948fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60ed6fbc31f7f893025e230f30b0ce4db0e595be448dfd97947a047a8bb948fe->enter($__internal_60ed6fbc31f7f893025e230f30b0ce4db0e595be448dfd97947a047a8bb948fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Index.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Home";
        
        $__internal_60ed6fbc31f7f893025e230f30b0ce4db0e595be448dfd97947a047a8bb948fe->leave($__internal_60ed6fbc31f7f893025e230f30b0ce4db0e595be448dfd97947a047a8bb948fe_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_140611548bcd935a736bf4f0ad0f117634e357e8204fcb29ef7b99c5544b99b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_140611548bcd935a736bf4f0ad0f117634e357e8204fcb29ef7b99c5544b99b9->enter($__internal_140611548bcd935a736bf4f0ad0f117634e357e8204fcb29ef7b99c5544b99b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Index.html.twig"));

        // line 5
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/Calculator_viwes.css"), "html", null, true);
        echo "\" />

    <ul>
        <li> <a id=\"Titulo\"> Inicio </a></li>
        <li> <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculator_RaSum");
        echo "\"> Suma </a></li>





    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
";
        
        $__internal_140611548bcd935a736bf4f0ad0f117634e357e8204fcb29ef7b99c5544b99b9->leave($__internal_140611548bcd935a736bf4f0ad0f117634e357e8204fcb29ef7b99c5544b99b9_prof);

    }

    public function getTemplateName()
    {
        return ":CalculatorRacional:Index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  64 => 10,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Home{% endblock %}
{% block body %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/Calculator_viwes.css') }}\" />

    <ul>
        <li> <a id=\"Titulo\"> Inicio </a></li>
        <li> <a href=\"{{ path('app_calculator_RaSum') }}\"> Suma </a></li>





    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
{% endblock %}
", ":CalculatorRacional:Index.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/CalculatorRacional/Index.html.twig");
    }
}
