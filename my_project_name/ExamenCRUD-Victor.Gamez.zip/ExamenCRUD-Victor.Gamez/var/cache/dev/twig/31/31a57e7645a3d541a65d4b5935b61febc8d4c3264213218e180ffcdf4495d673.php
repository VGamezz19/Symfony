<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_bad605738383737b739724ef4b8a14c4f3d4f48aeb50ec025baa9fb941743971 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd779a5f7b748acac7a045e4123459ad82d314603d491b2aef831472bef7a706 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd779a5f7b748acac7a045e4123459ad82d314603d491b2aef831472bef7a706->enter($__internal_dd779a5f7b748acac7a045e4123459ad82d314603d491b2aef831472bef7a706_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd779a5f7b748acac7a045e4123459ad82d314603d491b2aef831472bef7a706->leave($__internal_dd779a5f7b748acac7a045e4123459ad82d314603d491b2aef831472bef7a706_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_4cf47a74e9ee77e6b8d599f1fde4f22928d8ca1621f6c6e622ca2cb3275726e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cf47a74e9ee77e6b8d599f1fde4f22928d8ca1621f6c6e622ca2cb3275726e1->enter($__internal_4cf47a74e9ee77e6b8d599f1fde4f22928d8ca1621f6c6e622ca2cb3275726e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        
        $__internal_4cf47a74e9ee77e6b8d599f1fde4f22928d8ca1621f6c6e622ca2cb3275726e1->leave($__internal_4cf47a74e9ee77e6b8d599f1fde4f22928d8ca1621f6c6e622ca2cb3275726e1_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ea9e6801277ded873197323abc894c2ed883471080457d0e177a04c03778d424 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea9e6801277ded873197323abc894c2ed883471080457d0e177a04c03778d424->enter($__internal_ea9e6801277ded873197323abc894c2ed883471080457d0e177a04c03778d424_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_ea9e6801277ded873197323abc894c2ed883471080457d0e177a04c03778d424->leave($__internal_ea9e6801277ded873197323abc894c2ed883471080457d0e177a04c03778d424_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4825d13fe606b401fab526ebaa2645b769b70fa7114de6363218b1d89f522562 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4825d13fe606b401fab526ebaa2645b769b70fa7114de6363218b1d89f522562->enter($__internal_4825d13fe606b401fab526ebaa2645b769b70fa7114de6363218b1d89f522562_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_4825d13fe606b401fab526ebaa2645b769b70fa7114de6363218b1d89f522562->leave($__internal_4825d13fe606b401fab526ebaa2645b769b70fa7114de6363218b1d89f522562_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
