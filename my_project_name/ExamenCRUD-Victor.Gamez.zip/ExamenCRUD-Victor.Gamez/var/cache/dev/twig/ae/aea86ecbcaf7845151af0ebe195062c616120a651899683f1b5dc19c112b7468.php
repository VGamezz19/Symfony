<?php

/* Producto/form.twig */
class __TwigTemplate_b753aef0879571ed34520b4a3ed2f01876d2ccb50e07e76e2b4e339ebf4a93f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/form.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd5ca580bde7dac7513c5f6da46f60651b7ede88cc55e5bd666f00a49634e270 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cd5ca580bde7dac7513c5f6da46f60651b7ede88cc55e5bd666f00a49634e270->enter($__internal_cd5ca580bde7dac7513c5f6da46f60651b7ede88cc55e5bd666f00a49634e270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/form.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cd5ca580bde7dac7513c5f6da46f60651b7ede88cc55e5bd666f00a49634e270->leave($__internal_cd5ca580bde7dac7513c5f6da46f60651b7ede88cc55e5bd666f00a49634e270_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5392e06943035a3e4e035b8963e51b6296677f81bb0ee5ce360a517048408679 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5392e06943035a3e4e035b8963e51b6296677f81bb0ee5ce360a517048408679->enter($__internal_5392e06943035a3e4e035b8963e51b6296677f81bb0ee5ce360a517048408679_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/form.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_5392e06943035a3e4e035b8963e51b6296677f81bb0ee5ce360a517048408679->leave($__internal_5392e06943035a3e4e035b8963e51b6296677f81bb0ee5ce360a517048408679_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_8e8c4b5cddd980d86f89bb17247f8992d4232a25f99e0d7b4bd249c874b60e97 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e8c4b5cddd980d86f89bb17247f8992d4232a25f99e0d7b4bd249c874b60e97->enter($__internal_8e8c4b5cddd980d86f89bb17247f8992d4232a25f99e0d7b4bd249c874b60e97_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/form.twig"));

        // line 5
        echo "    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <div>
        <form method=\"post\" action=\"";
        // line 7
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo "\" novalidate=\"novalidate\">
            <div>
                <!-- form is based on User Entity -->
                ";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "value", array()));
        echo "
                <!-- http://stackoverflow.com/questions/12497133/directly-access-a-form-fields-value-when-overriding-widget-in-a-twig-template -->
                <ul>
                    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "errors", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
            // line 14
            echo "                        <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
            echo "</li>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "                </ul>
            </div>
            <div>";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors');
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "namel", array()), 'widget');
        echo "</div>
            <div>";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget');
        echo "</div>
            <div>";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "price", array()), 'widget');
        echo "</div>
            ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo " <!-- prints hidden fields and others -->
            <div><input type=\"submit\" value=\"Ok\"></div>
        </form>
    </div>
";
        
        $__internal_8e8c4b5cddd980d86f89bb17247f8992d4232a25f99e0d7b4bd249c874b60e97->leave($__internal_8e8c4b5cddd980d86f89bb17247f8992d4232a25f99e0d7b4bd249c874b60e97_prof);

    }

    public function getTemplateName()
    {
        return "Producto/form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 21,  100 => 20,  94 => 19,  87 => 18,  83 => 16,  74 => 14,  70 => 13,  64 => 10,  58 => 7,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <div>
        <form method=\"post\" action=\"{{ action }}\" novalidate=\"novalidate\">
            <div>
                <!-- form is based on User Entity -->
                {{ dump(form.vars.value) }}
                <!-- http://stackoverflow.com/questions/12497133/directly-access-a-form-fields-value-when-overriding-widget-in-a-twig-template -->
                <ul>
                    {% for error in form.vars.errors %}
                        <li>{{ error.message }}</li>
                    {% endfor %}
                </ul>
            </div>
            <div>{{ form_errors(form.name) }}{{ form_label(form.name) }}: {{ form_widget(form.namel) }}</div>
            <div>{{ form_label(form.description) }}: {{ form_widget(form.description) }}</div>
            <div>{{ form_label(form.price) }}: {{ form_widget(form.price) }}</div>
            {{ form_rest(form) }} <!-- prints hidden fields and others -->
            <div><input type=\"submit\" value=\"Ok\"></div>
        </form>
    </div>
{% endblock %}
", "Producto/form.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/form.twig");
    }
}
