<?php

/* :Calculator:Index.html.twig */
class __TwigTemplate_cbb0cc74699c5d798a0bdbc0f2d82b91eb69eae65d3191b92b2e9d0e43565bc3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":Calculator:Index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c6cb7786c3444edbfaa26fecbe3655930f870ec761dd82555e899d8c7933424f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6cb7786c3444edbfaa26fecbe3655930f870ec761dd82555e899d8c7933424f->enter($__internal_c6cb7786c3444edbfaa26fecbe3655930f870ec761dd82555e899d8c7933424f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Calculator:Index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c6cb7786c3444edbfaa26fecbe3655930f870ec761dd82555e899d8c7933424f->leave($__internal_c6cb7786c3444edbfaa26fecbe3655930f870ec761dd82555e899d8c7933424f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_a069889870bfece55d3c865dbe7df4b11b43091858eb86b6847ec411749b91a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a069889870bfece55d3c865dbe7df4b11b43091858eb86b6847ec411749b91a6->enter($__internal_a069889870bfece55d3c865dbe7df4b11b43091858eb86b6847ec411749b91a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Index.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Home";
        
        $__internal_a069889870bfece55d3c865dbe7df4b11b43091858eb86b6847ec411749b91a6->leave($__internal_a069889870bfece55d3c865dbe7df4b11b43091858eb86b6847ec411749b91a6_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_92f4b6bb00dbefb73155cccf8f2e81305ab93e833913161526b1bc92b9028bfa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_92f4b6bb00dbefb73155cccf8f2e81305ab93e833913161526b1bc92b9028bfa->enter($__internal_92f4b6bb00dbefb73155cccf8f2e81305ab93e833913161526b1bc92b9028bfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Index.html.twig"));

        // line 5
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/Calculator_viwes.css"), "html", null, true);
        echo "\" />

    <ul>
        <li> <a id=\"Titulo\"> Inicio </a></li>
        <li> <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculator_sum");
        echo "\"> Suma </a></li>
        <li> <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculator_res");
        echo "\"> Resta </a></li>




    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
";
        
        $__internal_92f4b6bb00dbefb73155cccf8f2e81305ab93e833913161526b1bc92b9028bfa->leave($__internal_92f4b6bb00dbefb73155cccf8f2e81305ab93e833913161526b1bc92b9028bfa_prof);

    }

    public function getTemplateName()
    {
        return ":Calculator:Index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 11,  64 => 10,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Home{% endblock %}
{% block body %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/Calculator_viwes.css') }}\" />

    <ul>
        <li> <a id=\"Titulo\"> Inicio </a></li>
        <li> <a href=\"{{ path('app_calculator_sum') }}\"> Suma </a></li>
        <li> <a href=\"{{ path('app_calculator_res') }}\"> Resta </a></li>




    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
{% endblock %}
", ":Calculator:Index.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Calculator/Index.html.twig");
    }
}
