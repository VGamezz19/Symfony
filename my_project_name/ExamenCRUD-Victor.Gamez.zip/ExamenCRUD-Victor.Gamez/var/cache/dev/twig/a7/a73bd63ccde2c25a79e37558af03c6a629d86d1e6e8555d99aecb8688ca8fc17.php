<?php

/* :CalculatorRacional:Form.html.twig */
class __TwigTemplate_9141a32cfdebc437a79026c37bab3c6eb3bf1eea1030ed29688e9c9b5ee98216 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":CalculatorRacional:Form.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_75784b7560c3ef31c0ca24297fa6fd4bdfccdc5f28b3469495dcbb32caf8242a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75784b7560c3ef31c0ca24297fa6fd4bdfccdc5f28b3469495dcbb32caf8242a->enter($__internal_75784b7560c3ef31c0ca24297fa6fd4bdfccdc5f28b3469495dcbb32caf8242a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":CalculatorRacional:Form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_75784b7560c3ef31c0ca24297fa6fd4bdfccdc5f28b3469495dcbb32caf8242a->leave($__internal_75784b7560c3ef31c0ca24297fa6fd4bdfccdc5f28b3469495dcbb32caf8242a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_0c8c2099a448032b0d274401e4d90c98f45e51eebf86e5883bf41c38bac419e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c8c2099a448032b0d274401e4d90c98f45e51eebf86e5883bf41c38bac419e1->enter($__internal_0c8c2099a448032b0d274401e4d90c98f45e51eebf86e5883bf41c38bac419e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Form.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_0c8c2099a448032b0d274401e4d90c98f45e51eebf86e5883bf41c38bac419e1->leave($__internal_0c8c2099a448032b0d274401e4d90c98f45e51eebf86e5883bf41c38bac419e1_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_198868b395719471ac712fd2d2d1a3de6f3dce5dcbbc1aedd6dcdbd76effcfef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_198868b395719471ac712fd2d2d1a3de6f3dce5dcbbc1aedd6dcdbd76effcfef->enter($__internal_198868b395719471ac712fd2d2d1a3de6f3dce5dcbbc1aedd6dcdbd76effcfef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Form.html.twig"));

        // line 5
        echo "    <form action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")));
        echo "\" method=\"post\"><!--Si ponemos Post, las variables no apareceran en la URL -->
        Op1 <input type=\"number\" name=\"op1\" placeholder=\"An integer\">
        Op3 <input type=\"number\" name=\"op3\" placeholder=\"An integer\"> <br>
        Op2 <input type=\"number\" name=\"op2\" placeholder=\"An integer\">
        Op4 <input type=\"number\" name=\"op4\" placeholder=\"An integer\"> <br>
        <input type=\"submit\" value=\"Calcula Racionales\">
    </form>
";
        
        $__internal_198868b395719471ac712fd2d2d1a3de6f3dce5dcbbc1aedd6dcdbd76effcfef->leave($__internal_198868b395719471ac712fd2d2d1a3de6f3dce5dcbbc1aedd6dcdbd76effcfef_prof);

    }

    public function getTemplateName()
    {
        return ":CalculatorRacional:Form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <form action=\"{{ path(action) }}\" method=\"post\"><!--Si ponemos Post, las variables no apareceran en la URL -->
        Op1 <input type=\"number\" name=\"op1\" placeholder=\"An integer\">
        Op3 <input type=\"number\" name=\"op3\" placeholder=\"An integer\"> <br>
        Op2 <input type=\"number\" name=\"op2\" placeholder=\"An integer\">
        Op4 <input type=\"number\" name=\"op4\" placeholder=\"An integer\"> <br>
        <input type=\"submit\" value=\"Calcula Racionales\">
    </form>
{% endblock %}
", ":CalculatorRacional:Form.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/CalculatorRacional/Form.html.twig");
    }
}
