<?php

/* :CalculatorRacional:Result.html.twig */
class __TwigTemplate_f9d70651aafb18f6028c518e29b446dddeee774343c6a728efebfd5a86cc143d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":CalculatorRacional:Result.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0585a9d06e73e897ca12bb338f65ab65e8d89d17d95c781f16b240259c4315e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0585a9d06e73e897ca12bb338f65ab65e8d89d17d95c781f16b240259c4315e4->enter($__internal_0585a9d06e73e897ca12bb338f65ab65e8d89d17d95c781f16b240259c4315e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":CalculatorRacional:Result.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0585a9d06e73e897ca12bb338f65ab65e8d89d17d95c781f16b240259c4315e4->leave($__internal_0585a9d06e73e897ca12bb338f65ab65e8d89d17d95c781f16b240259c4315e4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_bed173fb8bb6de11490c0e8636fbde97c00f03216fac27e6b534ba3bd10bc55f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bed173fb8bb6de11490c0e8636fbde97c00f03216fac27e6b534ba3bd10bc55f->enter($__internal_bed173fb8bb6de11490c0e8636fbde97c00f03216fac27e6b534ba3bd10bc55f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Result.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo "Result";
        
        $__internal_bed173fb8bb6de11490c0e8636fbde97c00f03216fac27e6b534ba3bd10bc55f->leave($__internal_bed173fb8bb6de11490c0e8636fbde97c00f03216fac27e6b534ba3bd10bc55f_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_550e9ee02cc783a9e74adc829a0e8634791018db4bde78d702c6686ef99e32d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_550e9ee02cc783a9e74adc829a0e8634791018db4bde78d702c6686ef99e32d1->enter($__internal_550e9ee02cc783a9e74adc829a0e8634791018db4bde78d702c6686ef99e32d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":CalculatorRacional:Result.html.twig"));

        // line 5
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/Calculator_viwes.css"), "html", null, true);
        echo "\" />

    <h1 id=\"Titulo\">";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["titulo"]) ? $context["titulo"] : $this->getContext($context, "titulo")), "html", null, true);
        echo "  <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculatorRacional_index");
        echo "\"> Index </a> </h1>
    <div class =\"Cuerpo\">
        <table style=\"margin-left: 45%;\">
            <tr>
                <th style=padding-right:25px;>";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["op1"]) ? $context["op1"] : $this->getContext($context, "op1")), "html", null, true);
        echo " </th>
                <th style=padding-right:25px;>";
        // line 13
        echo twig_escape_filter($this->env, (isset($context["op3"]) ? $context["op3"] : $this->getContext($context, "op3")), "html", null, true);
        echo "</th>
                <th>";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["RacionalResult1"]) ? $context["RacionalResult1"] : $this->getContext($context, "RacionalResult1")), "html", null, true);
        echo "</th>
            </tr>
            <tr>
                <th> ----  ";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["operacion"]) ? $context["operacion"] : $this->getContext($context, "operacion")), "html", null, true);
        echo "  </th>
                <th>----  = </th>
                <th>----</th>
            </tr>
            <tr>
                <th style=padding-right:25px;>";
        // line 22
        echo twig_escape_filter($this->env, (isset($context["op2"]) ? $context["op2"] : $this->getContext($context, "op2")), "html", null, true);
        echo " </th>
                <th style=padding-right:25px;>";
        // line 23
        echo twig_escape_filter($this->env, (isset($context["op4"]) ? $context["op4"] : $this->getContext($context, "op4")), "html", null, true);
        echo "</th>
                <th>";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["RacionalResult2"]) ? $context["RacionalResult2"] : $this->getContext($context, "RacionalResult2")), "html", null, true);
        echo "</th>
            </tr>
        </table>
    </div>
    <div class=\"gif\" align=\"center\">
        <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/putoAmo3.gif"), "html", null, true);
        echo "\" />
    </div>
";
        
        $__internal_550e9ee02cc783a9e74adc829a0e8634791018db4bde78d702c6686ef99e32d1->leave($__internal_550e9ee02cc783a9e74adc829a0e8634791018db4bde78d702c6686ef99e32d1_prof);

    }

    public function getTemplateName()
    {
        return ":CalculatorRacional:Result.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 29,  101 => 24,  97 => 23,  93 => 22,  85 => 17,  79 => 14,  75 => 13,  71 => 12,  62 => 8,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }}Result{% endblock %}
{% block body %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/Calculator_viwes.css') }}\" />

    <h1 id=\"Titulo\">{{ titulo }}  <a href=\"{{ path('app_calculatorRacional_index') }}\"> Index </a> </h1>
    <div class =\"Cuerpo\">
        <table style=\"margin-left: 45%;\">
            <tr>
                <th style=padding-right:25px;>{{ op1 }} </th>
                <th style=padding-right:25px;>{{ op3 }}</th>
                <th>{{ RacionalResult1 }}</th>
            </tr>
            <tr>
                <th> ----  {{ operacion }}  </th>
                <th>----  = </th>
                <th>----</th>
            </tr>
            <tr>
                <th style=padding-right:25px;>{{ op2 }} </th>
                <th style=padding-right:25px;>{{ op4 }}</th>
                <th>{{ RacionalResult2 }}</th>
            </tr>
        </table>
    </div>
    <div class=\"gif\" align=\"center\">
        <img src=\"{{ asset('img/putoAmo3.gif') }}\" />
    </div>
{% endblock %}
", ":CalculatorRacional:Result.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/CalculatorRacional/Result.html.twig");
    }
}
