<?php

/* Index.html.twig */
class __TwigTemplate_69df99f341949d525973d7e597637314daf25d521d0b9a69b48fd27e5ca61dda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b4291e8890b7859e6ee5cd3ff3dc3b713474a36c9d642cad313698e85160c771 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b4291e8890b7859e6ee5cd3ff3dc3b713474a36c9d642cad313698e85160c771->enter($__internal_b4291e8890b7859e6ee5cd3ff3dc3b713474a36c9d642cad313698e85160c771_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b4291e8890b7859e6ee5cd3ff3dc3b713474a36c9d642cad313698e85160c771->leave($__internal_b4291e8890b7859e6ee5cd3ff3dc3b713474a36c9d642cad313698e85160c771_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_72fe761d22b95352f7fc5a75d560ba5e1131cda78bee551ba6a4afccd3a3ed6a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_72fe761d22b95352f7fc5a75d560ba5e1131cda78bee551ba6a4afccd3a3ed6a->enter($__internal_72fe761d22b95352f7fc5a75d560ba5e1131cda78bee551ba6a4afccd3a3ed6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Index.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Home";
        
        $__internal_72fe761d22b95352f7fc5a75d560ba5e1131cda78bee551ba6a4afccd3a3ed6a->leave($__internal_72fe761d22b95352f7fc5a75d560ba5e1131cda78bee551ba6a4afccd3a3ed6a_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_7e3a812c56f8513b83f51f5bd0579585772afe437577e702da23bcd62db878f4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7e3a812c56f8513b83f51f5bd0579585772afe437577e702da23bcd62db878f4->enter($__internal_7e3a812c56f8513b83f51f5bd0579585772afe437577e702da23bcd62db878f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Index.html.twig"));

        // line 5
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/Calculator_viwes.css"), "html", null, true);
        echo "\" />

    <ul>
        <li> <a id=\"Titulo\"> Mis aplicaciones</a></li>

        <li> <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculator_index");
        echo "\"> Calculadora</a></li>
        <li> <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculatorRacional_index");
        echo "\"> Racional</a></li>
        <li> <a href=\"";
        // line 13
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_anadir_index");
        echo "\"> BBDD</a></li>





    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
";
        
        $__internal_7e3a812c56f8513b83f51f5bd0579585772afe437577e702da23bcd62db878f4->leave($__internal_7e3a812c56f8513b83f51f5bd0579585772afe437577e702da23bcd62db878f4_prof);

    }

    public function getTemplateName()
    {
        return "Index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  69 => 12,  65 => 11,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Home{% endblock %}
{% block body %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/Calculator_viwes.css') }}\" />

    <ul>
        <li> <a id=\"Titulo\"> Mis aplicaciones</a></li>

        <li> <a href=\"{{ path('app_calculator_index') }}\"> Calculadora</a></li>
        <li> <a href=\"{{ path('app_calculatorRacional_index') }}\"> Racional</a></li>
        <li> <a href=\"{{ path('app_anadir_index') }}\"> BBDD</a></li>





    </ul>
    <!-- Va por bloques, se refiere a ls bloques de la base.html.twig -->
{% endblock %}
", "Index.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Index.html.twig");
    }
}
