<?php

/* :Calculator:Result.html.twig */
class __TwigTemplate_f343ab2aa33f3d53a688dd6f20674e927a92aa092dad850351d04ed241daa519 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":Calculator:Result.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fea3d31d1cfa293e353b48634903f80b5b31bcf0abed0b8dd6d1c71ff861c9e9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fea3d31d1cfa293e353b48634903f80b5b31bcf0abed0b8dd6d1c71ff861c9e9->enter($__internal_fea3d31d1cfa293e353b48634903f80b5b31bcf0abed0b8dd6d1c71ff861c9e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Calculator:Result.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fea3d31d1cfa293e353b48634903f80b5b31bcf0abed0b8dd6d1c71ff861c9e9->leave($__internal_fea3d31d1cfa293e353b48634903f80b5b31bcf0abed0b8dd6d1c71ff861c9e9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_8ff44a4758016a4c2ac4d13dfd2e2da5f4bb19de6563a7c15542236b937b9992 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ff44a4758016a4c2ac4d13dfd2e2da5f4bb19de6563a7c15542236b937b9992->enter($__internal_8ff44a4758016a4c2ac4d13dfd2e2da5f4bb19de6563a7c15542236b937b9992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Result.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo "Result";
        
        $__internal_8ff44a4758016a4c2ac4d13dfd2e2da5f4bb19de6563a7c15542236b937b9992->leave($__internal_8ff44a4758016a4c2ac4d13dfd2e2da5f4bb19de6563a7c15542236b937b9992_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_491dd83deae2ecc3d8116547c5c1e5b0b51284c3331779b2e334d95a204fcf56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_491dd83deae2ecc3d8116547c5c1e5b0b51284c3331779b2e334d95a204fcf56->enter($__internal_491dd83deae2ecc3d8116547c5c1e5b0b51284c3331779b2e334d95a204fcf56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Result.html.twig"));

        // line 5
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/Calculator_viwes.css"), "html", null, true);
        echo "\" />




    <h1 id=\"Titulo\">";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["titulo"]) ? $context["titulo"] : $this->getContext($context, "titulo")), "html", null, true);
        echo "  <a href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_calculator_index");
        echo "\"> Index </a> </h1>
    <div class =\"Cuerpo\">  ";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["op1"]) ? $context["op1"] : $this->getContext($context, "op1")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["operacion"]) ? $context["operacion"] : $this->getContext($context, "operacion")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["op2"]) ? $context["op2"] : $this->getContext($context, "op2")), "html", null, true);
        echo " = ";
        echo twig_escape_filter($this->env, (isset($context["result"]) ? $context["result"] : $this->getContext($context, "result")), "html", null, true);
        echo "</div>

    <div class=\"gif\" align=\"center\">
        <img src=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("img/putoAmo3.gif"), "html", null, true);
        echo "\" />
    </div>
";
        
        $__internal_491dd83deae2ecc3d8116547c5c1e5b0b51284c3331779b2e334d95a204fcf56->leave($__internal_491dd83deae2ecc3d8116547c5c1e5b0b51284c3331779b2e334d95a204fcf56_prof);

    }

    public function getTemplateName()
    {
        return ":Calculator:Result.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 15,  71 => 12,  65 => 11,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }}Result{% endblock %}
{% block body %}

    <link rel=\"stylesheet\" href=\"{{ asset('css/Calculator_viwes.css') }}\" />




    <h1 id=\"Titulo\">{{ titulo }}  <a href=\"{{ path('app_calculator_index') }}\"> Index </a> </h1>
    <div class =\"Cuerpo\">  {{ op1 }} {{ operacion }} {{ op2 }} = {{ result }}</div>

    <div class=\"gif\" align=\"center\">
        <img src=\"{{ asset('img/putoAmo3.gif') }}\" />
    </div>
{% endblock %}
", ":Calculator:Result.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Calculator/Result.html.twig");
    }
}
