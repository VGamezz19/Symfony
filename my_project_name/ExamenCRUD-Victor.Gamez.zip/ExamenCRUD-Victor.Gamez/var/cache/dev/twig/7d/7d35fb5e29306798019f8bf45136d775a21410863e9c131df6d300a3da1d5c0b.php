<?php

/* Producto/index.html.twig */
class __TwigTemplate_26fbbe11255723bbae2b9273fc430ed1f7ee3106d18fb2b43e949512fda24b31 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_567d319d039f769adf6375bca3ef502216243a86b84adfb274948adee99bac7f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_567d319d039f769adf6375bca3ef502216243a86b84adfb274948adee99bac7f->enter($__internal_567d319d039f769adf6375bca3ef502216243a86b84adfb274948adee99bac7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_567d319d039f769adf6375bca3ef502216243a86b84adfb274948adee99bac7f->leave($__internal_567d319d039f769adf6375bca3ef502216243a86b84adfb274948adee99bac7f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_9d3e6782e40f0346bd2c065b3a9f040a489f17178db0fc09009bfb5604bdc7a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d3e6782e40f0346bd2c065b3a9f040a489f17178db0fc09009bfb5604bdc7a4->enter($__internal_9d3e6782e40f0346bd2c065b3a9f040a489f17178db0fc09009bfb5604bdc7a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/index.html.twig"));

        echo " Productos";
        
        $__internal_9d3e6782e40f0346bd2c065b3a9f040a489f17178db0fc09009bfb5604bdc7a4->leave($__internal_9d3e6782e40f0346bd2c065b3a9f040a489f17178db0fc09009bfb5604bdc7a4_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_0e618cfb6fe391ad73156630b142ed914c53aefc13f1578a9e3d6816d433be4d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e618cfb6fe391ad73156630b142ed914c53aefc13f1578a9e3d6816d433be4d->enter($__internal_0e618cfb6fe391ad73156630b142ed914c53aefc13f1578a9e3d6816d433be4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/index.html.twig"));

        // line 5
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/producto_tabla.css"), "html", null, true);
        echo "\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>precio</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["productos"]) ? $context["productos"] : $this->getContext($context, "productos")));
        foreach ($context['_seq'] as $context["_key"] => $context["producto"]) {
            // line 22
            echo "            <tbody>
                <tr>
                    <th>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "name", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "description", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "price", array()), "html", null, true);
            echo " € </th>
                    <th>";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["producto"], "createdAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo "</th>
                    <th>";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["producto"], "updatedAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo " </th>
                    <th><a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_update", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\"> UPDATE</a> </th>
                    <th><a href=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_delete", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\"> DELETE</a></th>
                </tr>
            </tbody>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['producto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </table>
    </form>


    <form action=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_create");
        echo "\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["gif"]) ? $context["gif"] : $this->getContext($context, "gif"))), "html", null, true);
        echo "\" />
    </form>



";
        
        $__internal_0e618cfb6fe391ad73156630b142ed914c53aefc13f1578a9e3d6816d433be4d->leave($__internal_0e618cfb6fe391ad73156630b142ed914c53aefc13f1578a9e3d6816d433be4d_prof);

    }

    public function getTemplateName()
    {
        return "Producto/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 44,  125 => 39,  119 => 35,  109 => 31,  105 => 30,  101 => 29,  97 => 28,  93 => 27,  89 => 26,  85 => 25,  81 => 24,  77 => 22,  73 => 21,  53 => 5,  47 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %} Productos{% endblock %}
{% block body %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/producto_tabla.css') }}\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>precio</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    {% for producto in productos %}
            <tbody>
                <tr>
                    <th>{{ producto.id}}</th>
                    <th>{{ producto.name}}</th>
                    <th>{{ producto.description }}</th>
                    <th>{{ producto.price}} € </th>
                    <th>{{ producto.createdAt|date(\"d/m/y H:i:s\") }}</th>
                    <th>{{ producto.updatedAt|date(\"d/m/y H:i:s\")}} </th>
                    <th><a href=\"{{ path('app_product_update', {'id': producto.id}) }}\"> UPDATE</a> </th>
                    <th><a href=\"{{ path('app_product_delete', {'id': producto.id}) }}\"> DELETE</a></th>
                </tr>
            </tbody>
    {% endfor %}
    </table>
    </form>


    <form action=\"{{ path('app_product_create') }}\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"{{ asset(gif) }}\" />
    </form>



{% endblock %}
", "Producto/index.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/index.html.twig");
    }
}
