<?php

/* gfd/form.html.twig */
class __TwigTemplate_ee1803e1d6cfc481700b5c7029d793b3f7fa2ec6c8ddfc00d1a27fb2e8cf272c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "gfd/form.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ec26bfa7f0396c383908c929be344440ea7223cab42f23987e1a7a88c9a8195d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec26bfa7f0396c383908c929be344440ea7223cab42f23987e1a7a88c9a8195d->enter($__internal_ec26bfa7f0396c383908c929be344440ea7223cab42f23987e1a7a88c9a8195d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "gfd/form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ec26bfa7f0396c383908c929be344440ea7223cab42f23987e1a7a88c9a8195d->leave($__internal_ec26bfa7f0396c383908c929be344440ea7223cab42f23987e1a7a88c9a8195d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_1e6e9248fa549bf0109d8fcbc39d253449a26684c3c52b3f407bf3407f7708b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e6e9248fa549bf0109d8fcbc39d253449a26684c3c52b3f407bf3407f7708b0->enter($__internal_1e6e9248fa549bf0109d8fcbc39d253449a26684c3c52b3f407bf3407f7708b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "gfd/form.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_1e6e9248fa549bf0109d8fcbc39d253449a26684c3c52b3f407bf3407f7708b0->leave($__internal_1e6e9248fa549bf0109d8fcbc39d253449a26684c3c52b3f407bf3407f7708b0_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_915e91650eefd541519dff508b48bd686153e9c0f6ec2320032d51a1765e2fc3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_915e91650eefd541519dff508b48bd686153e9c0f6ec2320032d51a1765e2fc3->enter($__internal_915e91650eefd541519dff508b48bd686153e9c0f6ec2320032d51a1765e2fc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "gfd/form.html.twig"));

        // line 5
        echo "    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/producto_tabla.css"), "html", null, true);
        echo "\" />

    <div>
       <form method=\"post\" action=\"";
        // line 9
        echo twig_escape_filter($this->env, (isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), "html", null, true);
        echo "\" novalidate=\"novalidate\">
           <div>

               ";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\DumpExtension')->dump($this->env, $context, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "value", array()));
        echo "

               <ul>
                   ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "errors", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
            // line 16
            echo "                        <li>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
            echo "</li>
                   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 18
        echo "               </ul>
           </div>
           <div>";
        // line 20
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "usrger", array()), 'errors');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "usrger", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "usrger", array()), 'widget');
        echo "</div>
           <div>";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prigrid", array()), 'errors');
        echo " ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prigrid", array()), 'label');
        echo ": ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "prigrid", array()), 'widget');
        echo "</div>
           ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'rest');
        echo "

           <button value=\"CREATE\" id=\"boton\">
               <h1>Confirmar</h1>
           </button>

           <img id = \"imagen\"src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["gif"]) ? $context["gif"] : $this->getContext($context, "gif"))), "html", null, true);
        echo "\" />
       </form>
    </div>
";
        
        $__internal_915e91650eefd541519dff508b48bd686153e9c0f6ec2320032d51a1765e2fc3->leave($__internal_915e91650eefd541519dff508b48bd686153e9c0f6ec2320032d51a1765e2fc3_prof);

    }

    public function getTemplateName()
    {
        return "gfd/form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 28,  108 => 22,  100 => 21,  92 => 20,  88 => 18,  79 => 16,  75 => 15,  69 => 12,  63 => 9,  57 => 6,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <!-- http://stackoverflow.com/questions/18848870/how-to-display-all-form-error-at-one-place -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/producto_tabla.css') }}\" />

    <div>
       <form method=\"post\" action=\"{{ action }}\" novalidate=\"novalidate\">
           <div>

               {{ dump(form.vars.value) }}

               <ul>
                   {%  for error in form.vars.errors %}
                        <li>{{ error.message }}</li>
                   {% endfor %}
               </ul>
           </div>
           <div>{{ form_errors(form.usrger) }} {{ form_label(form.usrger) }}: {{ form_widget(form.usrger) }}</div>
           <div>{{ form_errors(form.prigrid) }} {{ form_label(form.prigrid) }}: {{ form_widget(form.prigrid)  }}</div>
           {{ form_rest(form) }}

           <button value=\"CREATE\" id=\"boton\">
               <h1>Confirmar</h1>
           </button>

           <img id = \"imagen\"src=\"{{ asset(gif) }}\" />
       </form>
    </div>
{% endblock %}
", "gfd/form.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/gfd/form.html.twig");
    }
}
