<?php

/* Producto/index.html.twig */
class __TwigTemplate_57aea56b5117aa3cceee437070bbf42070819e40656f2cd2c03d4a8c80bdb75f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_533afda338352b382b82cc33efd31a560e6fd564218f64fa3c0691f0aa5f5d98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_533afda338352b382b82cc33efd31a560e6fd564218f64fa3c0691f0aa5f5d98->enter($__internal_533afda338352b382b82cc33efd31a560e6fd564218f64fa3c0691f0aa5f5d98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_533afda338352b382b82cc33efd31a560e6fd564218f64fa3c0691f0aa5f5d98->leave($__internal_533afda338352b382b82cc33efd31a560e6fd564218f64fa3c0691f0aa5f5d98_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_6aa2558ead623701dcb4f8cabb4cbc7219b602471730f155e53d3b2497570a8a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6aa2558ead623701dcb4f8cabb4cbc7219b602471730f155e53d3b2497570a8a->enter($__internal_6aa2558ead623701dcb4f8cabb4cbc7219b602471730f155e53d3b2497570a8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/index.html.twig"));

        echo " Productos";
        
        $__internal_6aa2558ead623701dcb4f8cabb4cbc7219b602471730f155e53d3b2497570a8a->leave($__internal_6aa2558ead623701dcb4f8cabb4cbc7219b602471730f155e53d3b2497570a8a_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_9268063577c5c349fa6feaf16f1e14b19007a574fc7336fc206b20c7fac36b99 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9268063577c5c349fa6feaf16f1e14b19007a574fc7336fc206b20c7fac36b99->enter($__internal_9268063577c5c349fa6feaf16f1e14b19007a574fc7336fc206b20c7fac36b99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/index.html.twig"));

        // line 5
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/producto_tabla.css"), "html", null, true);
        echo "\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>precio</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["productos"]) ? $context["productos"] : $this->getContext($context, "productos")));
        foreach ($context['_seq'] as $context["_key"] => $context["producto"]) {
            // line 22
            echo "            <tbody>
                <tr>
                    <th>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "id", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "name", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "description", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["producto"], "price", array()), "html", null, true);
            echo " € </th>
                    <th>";
            // line 28
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["producto"], "createdAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo "</th>
                    <th>";
            // line 29
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["producto"], "updatedAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo " </th>
                    <th><a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_update", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\"> UPDATE</a> </th>
                    <th><a href=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_delete", array("id" => $this->getAttribute($context["producto"], "id", array()))), "html", null, true);
            echo "\"> DELETE</a></th>
                </tr>
            </tbody>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['producto'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 35
        echo "    </table>
    </form>


    <form action=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_product_create");
        echo "\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["gif"]) ? $context["gif"] : $this->getContext($context, "gif"))), "html", null, true);
        echo "\" />
    </form>



";
        
        $__internal_9268063577c5c349fa6feaf16f1e14b19007a574fc7336fc206b20c7fac36b99->leave($__internal_9268063577c5c349fa6feaf16f1e14b19007a574fc7336fc206b20c7fac36b99_prof);

    }

    public function getTemplateName()
    {
        return "Producto/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 44,  125 => 39,  119 => 35,  109 => 31,  105 => 30,  101 => 29,  97 => 28,  93 => 27,  89 => 26,  85 => 25,  81 => 24,  77 => 22,  73 => 21,  53 => 5,  47 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %} Productos{% endblock %}
{% block body %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/producto_tabla.css') }}\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripcion</th>
                <th>precio</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    {% for producto in productos %}
            <tbody>
                <tr>
                    <th>{{ producto.id}}</th>
                    <th>{{ producto.name}}</th>
                    <th>{{ producto.description }}</th>
                    <th>{{ producto.price}} € </th>
                    <th>{{ producto.createdAt|date(\"d/m/y H:i:s\") }}</th>
                    <th>{{ producto.updatedAt|date(\"d/m/y H:i:s\")}} </th>
                    <th><a href=\"{{ path('app_product_update', {'id': producto.id}) }}\"> UPDATE</a> </th>
                    <th><a href=\"{{ path('app_product_delete', {'id': producto.id}) }}\"> DELETE</a></th>
                </tr>
            </tbody>
    {% endfor %}
    </table>
    </form>


    <form action=\"{{ path('app_product_create') }}\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"{{ asset(gif) }}\" />
    </form>



{% endblock %}
", "Producto/index.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/index.html.twig");
    }
}
