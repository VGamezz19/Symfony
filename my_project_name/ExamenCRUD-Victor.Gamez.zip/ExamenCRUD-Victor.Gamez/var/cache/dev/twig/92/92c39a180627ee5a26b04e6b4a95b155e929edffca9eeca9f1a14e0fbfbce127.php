<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_aa4fc203d7612efd11f5c5177da7b86d0cd0b33659a430fb8964c8b64715ea05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a31d9ca9b5e5f9aca4b5f8d13a91aadeb593131e8b073936e63ff272fc10c65e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a31d9ca9b5e5f9aca4b5f8d13a91aadeb593131e8b073936e63ff272fc10c65e->enter($__internal_a31d9ca9b5e5f9aca4b5f8d13a91aadeb593131e8b073936e63ff272fc10c65e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a31d9ca9b5e5f9aca4b5f8d13a91aadeb593131e8b073936e63ff272fc10c65e->leave($__internal_a31d9ca9b5e5f9aca4b5f8d13a91aadeb593131e8b073936e63ff272fc10c65e_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_80086800d2eb97cf99c2e89a2c958d570bac7e35a766c85f415c648b3a441647 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80086800d2eb97cf99c2e89a2c958d570bac7e35a766c85f415c648b3a441647->enter($__internal_80086800d2eb97cf99c2e89a2c958d570bac7e35a766c85f415c648b3a441647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@Twig/Exception/exception_full.html.twig"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_80086800d2eb97cf99c2e89a2c958d570bac7e35a766c85f415c648b3a441647->leave($__internal_80086800d2eb97cf99c2e89a2c958d570bac7e35a766c85f415c648b3a441647_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_14a9ab5b87fac30ce793687dffb9e5d92ed25becfa9f9b1a4fd2192fffec738e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_14a9ab5b87fac30ce793687dffb9e5d92ed25becfa9f9b1a4fd2192fffec738e->enter($__internal_14a9ab5b87fac30ce793687dffb9e5d92ed25becfa9f9b1a4fd2192fffec738e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@Twig/Exception/exception_full.html.twig"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_14a9ab5b87fac30ce793687dffb9e5d92ed25becfa9f9b1a4fd2192fffec738e->leave($__internal_14a9ab5b87fac30ce793687dffb9e5d92ed25becfa9f9b1a4fd2192fffec738e_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_4d418d046a6046796689bb29ad971c07d7f0e670ee2e89c9a410acc0ac7db40f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d418d046a6046796689bb29ad971c07d7f0e670ee2e89c9a410acc0ac7db40f->enter($__internal_4d418d046a6046796689bb29ad971c07d7f0e670ee2e89c9a410acc0ac7db40f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@Twig/Exception/exception_full.html.twig"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_4d418d046a6046796689bb29ad971c07d7f0e670ee2e89c9a410acc0ac7db40f->leave($__internal_4d418d046a6046796689bb29ad971c07d7f0e670ee2e89c9a410acc0ac7db40f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
", "@Twig/Exception/exception_full.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
