<?php

/* :Calculator:Form.html.twig */
class __TwigTemplate_38c5399dc9cc661fa84946d15262661ad86e3e805dcef6b6eb7a589c2258b0c4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", ":Calculator:Form.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2df78802a9ad8584981a1a6eda7cc175d7c864f634cbf41ee72989b80e108f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a2df78802a9ad8584981a1a6eda7cc175d7c864f634cbf41ee72989b80e108f9->enter($__internal_a2df78802a9ad8584981a1a6eda7cc175d7c864f634cbf41ee72989b80e108f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":Calculator:Form.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a2df78802a9ad8584981a1a6eda7cc175d7c864f634cbf41ee72989b80e108f9->leave($__internal_a2df78802a9ad8584981a1a6eda7cc175d7c864f634cbf41ee72989b80e108f9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7499ae472b6a18833d4bf49ce6620282ad9f5b835010d0060dea2d25c2e8114f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7499ae472b6a18833d4bf49ce6620282ad9f5b835010d0060dea2d25c2e8114f->enter($__internal_7499ae472b6a18833d4bf49ce6620282ad9f5b835010d0060dea2d25c2e8114f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Form.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_7499ae472b6a18833d4bf49ce6620282ad9f5b835010d0060dea2d25c2e8114f->leave($__internal_7499ae472b6a18833d4bf49ce6620282ad9f5b835010d0060dea2d25c2e8114f_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_2ae938a3abe08848a0b8feba90b60cbc7dc8279ad75fdcc0f2090b0135e1515e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2ae938a3abe08848a0b8feba90b60cbc7dc8279ad75fdcc0f2090b0135e1515e->enter($__internal_2ae938a3abe08848a0b8feba90b60cbc7dc8279ad75fdcc0f2090b0135e1515e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", ":Calculator:Form.html.twig"));

        // line 5
        echo "    <form action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")));
        echo "\" method=\"post\"><!--Si ponemos Post, las variables no apareceran en la URL -->
        Op1 <input type=\"number\" name=\"op1\" placeholder=\"An integer\"> <br>
        Op2 <input type=\"number\" name=\"op2\" placeholder=\"An integer\"> <br>
        <input type=\"submit\" value=\"Calcula\">
    </form>
";
        
        $__internal_2ae938a3abe08848a0b8feba90b60cbc7dc8279ad75fdcc0f2090b0135e1515e->leave($__internal_2ae938a3abe08848a0b8feba90b60cbc7dc8279ad75fdcc0f2090b0135e1515e_prof);

    }

    public function getTemplateName()
    {
        return ":Calculator:Form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <form action=\"{{ path(action) }}\" method=\"post\"><!--Si ponemos Post, las variables no apareceran en la URL -->
        Op1 <input type=\"number\" name=\"op1\" placeholder=\"An integer\"> <br>
        Op2 <input type=\"number\" name=\"op2\" placeholder=\"An integer\"> <br>
        <input type=\"submit\" value=\"Calcula\">
    </form>
{% endblock %}
", ":Calculator:Form.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Calculator/Form.html.twig");
    }
}
