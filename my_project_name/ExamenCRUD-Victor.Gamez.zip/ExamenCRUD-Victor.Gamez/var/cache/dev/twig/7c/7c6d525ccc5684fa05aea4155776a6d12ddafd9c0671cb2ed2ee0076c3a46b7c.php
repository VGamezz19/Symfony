<?php

/* gfd/index.html.twig */
class __TwigTemplate_2131fe3cb0f2edf8e027309d778728814699e172ad192d58976f43cec429fc05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "gfd/index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1b1e481c433410b650d49b93117f14aa07afe331d955195ec26b3188dd180426 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b1e481c433410b650d49b93117f14aa07afe331d955195ec26b3188dd180426->enter($__internal_1b1e481c433410b650d49b93117f14aa07afe331d955195ec26b3188dd180426_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "gfd/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1b1e481c433410b650d49b93117f14aa07afe331d955195ec26b3188dd180426->leave($__internal_1b1e481c433410b650d49b93117f14aa07afe331d955195ec26b3188dd180426_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5379a1439c22e17695794b9089069e0576e6084311d40eeff5509e90bba2b41a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5379a1439c22e17695794b9089069e0576e6084311d40eeff5509e90bba2b41a->enter($__internal_5379a1439c22e17695794b9089069e0576e6084311d40eeff5509e90bba2b41a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "gfd/index.html.twig"));

        echo " Productos";
        
        $__internal_5379a1439c22e17695794b9089069e0576e6084311d40eeff5509e90bba2b41a->leave($__internal_5379a1439c22e17695794b9089069e0576e6084311d40eeff5509e90bba2b41a_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_a8efa17596c8d7c57d047833e0b617509121fab3b6d8d7c152263a361a1c59d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8efa17596c8d7c57d047833e0b617509121fab3b6d8d7c152263a361a1c59d4->enter($__internal_a8efa17596c8d7c57d047833e0b617509121fab3b6d8d7c152263a361a1c59d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "gfd/index.html.twig"));

        // line 5
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/producto_tabla.css"), "html", null, true);
        echo "\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>usrger</th>
                <th>prigrid</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["gfds"]) ? $context["gfds"] : $this->getContext($context, "gfds")));
        foreach ($context['_seq'] as $context["_key"] => $context["gfd"]) {
            // line 21
            echo "            <tbody>
                <tr>
                    <th>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["gfd"], "id", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["gfd"], "usrger", array()), "html", null, true);
            echo "</th>
                    <th>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["gfd"], "prigrid", array()), "html", null, true);
            echo " € </th>
                    <th>";
            // line 26
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["gfd"], "createdAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo "</th>
                    <th>";
            // line 27
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["gfd"], "updatedAt", array()), "d/m/y H:i:s"), "html", null, true);
            echo " </th>
                    <th><a href=\"";
            // line 28
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_gfd_update", array("id" => $this->getAttribute($context["gfd"], "id", array()))), "html", null, true);
            echo "\"> UPDATE</a> </th>
                    <th><a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_gfd_delete", array("id" => $this->getAttribute($context["gfd"], "id", array()))), "html", null, true);
            echo "\"> DELETE</a></th>
                </tr>
            </tbody>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gfd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "    </table>
    </form>


    <form action=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_gfd_create");
        echo "\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl((isset($context["gif"]) ? $context["gif"] : $this->getContext($context, "gif"))), "html", null, true);
        echo "\" />
    </form>



";
        
        $__internal_a8efa17596c8d7c57d047833e0b617509121fab3b6d8d7c152263a361a1c59d4->leave($__internal_a8efa17596c8d7c57d047833e0b617509121fab3b6d8d7c152263a361a1c59d4_prof);

    }

    public function getTemplateName()
    {
        return "gfd/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 42,  120 => 37,  114 => 33,  104 => 29,  100 => 28,  96 => 27,  92 => 26,  88 => 25,  84 => 24,  80 => 23,  76 => 21,  72 => 20,  53 => 5,  47 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %} Productos{% endblock %}
{% block body %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/producto_tabla.css') }}\" />

    <form>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>usrger</th>
                <th>prigrid</th>
                <th>Fecha de creacion</th>
                <th>Fecha Update</th>
                <th>Actualizar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
    {% for gfd in gfds %}
            <tbody>
                <tr>
                    <th>{{ gfd.id}}</th>
                    <th>{{ gfd.usrger}}</th>
                    <th>{{ gfd.prigrid}} € </th>
                    <th>{{ gfd.createdAt|date(\"d/m/y H:i:s\") }}</th>
                    <th>{{ gfd.updatedAt|date(\"d/m/y H:i:s\")}} </th>
                    <th><a href=\"{{ path('app_gfd_update', {'id': gfd.id}) }}\"> UPDATE</a> </th>
                    <th><a href=\"{{ path('app_gfd_delete', {'id': gfd.id}) }}\"> DELETE</a></th>
                </tr>
            </tbody>
    {% endfor %}
    </table>
    </form>


    <form action=\"{{ path('app_gfd_create') }}\" method=\"post\">
        <button value=\"CREATE\" id=\"boton\">
            <h1>CREATE</h1>
        </button>

        <img id = \"imagen\"src=\"{{ asset(gif) }}\" />
    </form>



{% endblock %}
", "gfd/index.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/gfd/index.html.twig");
    }
}
