<?php

/* ::base.html.twig */
class __TwigTemplate_2aa6b54a7b7e236a89128cb5ffcf87325ed375fbfb00ea9a14b0872baf311130 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aef33902e9544203958c738057958f5671bdbc5ae273311a48d9d753cab69665 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aef33902e9544203958c738057958f5671bdbc5ae273311a48d9d753cab69665->enter($__internal_aef33902e9544203958c738057958f5671bdbc5ae273311a48d9d753cab69665_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <ul>
        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "messages"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 12
            echo "            <li>";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "

        </ul>
        ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 18
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 19
        echo "    </body>
</html>
";
        
        $__internal_aef33902e9544203958c738057958f5671bdbc5ae273311a48d9d753cab69665->leave($__internal_aef33902e9544203958c738057958f5671bdbc5ae273311a48d9d753cab69665_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_79487ff573749438d3b7b74072869f607321062869dd0ad4710b2daeacb138ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_79487ff573749438d3b7b74072869f607321062869dd0ad4710b2daeacb138ad->enter($__internal_79487ff573749438d3b7b74072869f607321062869dd0ad4710b2daeacb138ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        echo "Welcome!";
        
        $__internal_79487ff573749438d3b7b74072869f607321062869dd0ad4710b2daeacb138ad->leave($__internal_79487ff573749438d3b7b74072869f607321062869dd0ad4710b2daeacb138ad_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e29060dccf85ffa2e123f1dbbfef699185f4b0747d72882643bfbdc253c00f0c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e29060dccf85ffa2e123f1dbbfef699185f4b0747d72882643bfbdc253c00f0c->enter($__internal_e29060dccf85ffa2e123f1dbbfef699185f4b0747d72882643bfbdc253c00f0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_e29060dccf85ffa2e123f1dbbfef699185f4b0747d72882643bfbdc253c00f0c->leave($__internal_e29060dccf85ffa2e123f1dbbfef699185f4b0747d72882643bfbdc253c00f0c_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_04a73aa473c2e618c8e671c875513f65867c0e8719c835f7f7b1273dcd7c925e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_04a73aa473c2e618c8e671c875513f65867c0e8719c835f7f7b1273dcd7c925e->enter($__internal_04a73aa473c2e618c8e671c875513f65867c0e8719c835f7f7b1273dcd7c925e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_04a73aa473c2e618c8e671c875513f65867c0e8719c835f7f7b1273dcd7c925e->leave($__internal_04a73aa473c2e618c8e671c875513f65867c0e8719c835f7f7b1273dcd7c925e_prof);

    }

    // line 18
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_11567428a5e4511b3d8a3c2d66d63f670a222d856eaeab9256b9123213740b5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11567428a5e4511b3d8a3c2d66d63f670a222d856eaeab9256b9123213740b5b->enter($__internal_11567428a5e4511b3d8a3c2d66d63f670a222d856eaeab9256b9123213740b5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_11567428a5e4511b3d8a3c2d66d63f670a222d856eaeab9256b9123213740b5b->leave($__internal_11567428a5e4511b3d8a3c2d66d63f670a222d856eaeab9256b9123213740b5b_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 18,  101 => 17,  90 => 6,  78 => 5,  69 => 19,  66 => 18,  64 => 17,  59 => 14,  50 => 12,  46 => 11,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        <ul>
        {% for message in app.session.flashBag.get('messages') %}
            <li>{{ message }}</li>
        {% endfor %}


        </ul>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/media/victor/VictorGamez/Mega/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/base.html.twig");
    }
}
