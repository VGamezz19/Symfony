<?php

/* Producto/update.html.twig */
class __TwigTemplate_20b564a460abbfb7efd3d23a32326ac0c4ffa8a9bc769e52c0270d16ec2e789a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/update.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7744424eec0dae2c3f962411235ec85af007b81a49ac42aee87136f0bff521f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7744424eec0dae2c3f962411235ec85af007b81a49ac42aee87136f0bff521f8->enter($__internal_7744424eec0dae2c3f962411235ec85af007b81a49ac42aee87136f0bff521f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/update.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7744424eec0dae2c3f962411235ec85af007b81a49ac42aee87136f0bff521f8->leave($__internal_7744424eec0dae2c3f962411235ec85af007b81a49ac42aee87136f0bff521f8_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_2f381946a7c8dd57e8f7d9f26f8fdf0e2be626b983fbaef6fde0a3bd64764039 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f381946a7c8dd57e8f7d9f26f8fdf0e2be626b983fbaef6fde0a3bd64764039->enter($__internal_2f381946a7c8dd57e8f7d9f26f8fdf0e2be626b983fbaef6fde0a3bd64764039_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/update.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_2f381946a7c8dd57e8f7d9f26f8fdf0e2be626b983fbaef6fde0a3bd64764039->leave($__internal_2f381946a7c8dd57e8f7d9f26f8fdf0e2be626b983fbaef6fde0a3bd64764039_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_02f5e8f95a2d76545dbae55a400653d8ca34fbe01a2f08d0c352cfb4cc1b5977 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_02f5e8f95a2d76545dbae55a400653d8ca34fbe01a2f08d0c352cfb4cc1b5977->enter($__internal_02f5e8f95a2d76545dbae55a400653d8ca34fbe01a2f08d0c352cfb4cc1b5977_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/update.html.twig"));

        // line 5
        echo "    <form action=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")), array("id" => $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "id", array()))), "html", null, true);
        echo "\" method=\"post\">

        name <input type=\"text\" name=\"name\" placeholder=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "name", array()), "html", null, true);
        echo "\"><br>
        descripcion <input type=\"text\" name=\"description\" placeholder=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "description", array()), "html", null, true);
        echo "\"> <br>
        precio<input type=\"number\" name=\"price\" placeholder=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "price", array()), "html", null, true);
        echo "€\"><br>
        ";
        // line 10
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "createdAt", array()), "d/m/y H:i:s"), "html", null, true);
        echo " <br>
        ";
        // line 11
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "updatedAt", array()), "d/m/y H:i:s"), "html", null, true);
        echo " <br>
        numero ID del producto ";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["producto"]) ? $context["producto"] : $this->getContext($context, "producto")), "id", array()), "html", null, true);
        echo "
        <input type=\"submit\" value=\"Update Producto\">
    </form>
";
        
        $__internal_02f5e8f95a2d76545dbae55a400653d8ca34fbe01a2f08d0c352cfb4cc1b5977->leave($__internal_02f5e8f95a2d76545dbae55a400653d8ca34fbe01a2f08d0c352cfb4cc1b5977_prof);

    }

    public function getTemplateName()
    {
        return "Producto/update.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 12,  76 => 11,  72 => 10,  68 => 9,  64 => 8,  60 => 7,  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <form action=\"{{ path(action,  {'id': producto.id}) }}\" method=\"post\">

        name <input type=\"text\" name=\"name\" placeholder=\"{{ producto.name }}\"><br>
        descripcion <input type=\"text\" name=\"description\" placeholder=\"{{ producto.description }}\"> <br>
        precio<input type=\"number\" name=\"price\" placeholder=\"{{ producto.price }}€\"><br>
        {{ producto.createdAt|date(\"d/m/y H:i:s\") }} <br>
        {{ producto.updatedAt|date(\"d/m/y H:i:s\") }} <br>
        numero ID del producto {{ producto.id }}
        <input type=\"submit\" value=\"Update Producto\">
    </form>
{% endblock %}
", "Producto/update.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/update.html.twig");
    }
}
