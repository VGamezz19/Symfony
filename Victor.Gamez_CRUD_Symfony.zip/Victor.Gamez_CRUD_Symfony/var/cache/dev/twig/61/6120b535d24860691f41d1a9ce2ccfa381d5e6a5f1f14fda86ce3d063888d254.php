<?php

/* ::base.html.twig */
class __TwigTemplate_2795b2095540eb33a15a1b11ed21318c81c4c1df80ecae1d63a14d679bcccb93 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_886be532dc5212862480e7c92ea64592bb13658b9e4fbef263f636f907a28d78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_886be532dc5212862480e7c92ea64592bb13658b9e4fbef263f636f907a28d78->enter($__internal_886be532dc5212862480e7c92ea64592bb13658b9e4fbef263f636f907a28d78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        <ul>
        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "messages"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 12
            echo "            <li>";
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 14
        echo "

        </ul>
        ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 18
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 19
        echo "    </body>
</html>
";
        
        $__internal_886be532dc5212862480e7c92ea64592bb13658b9e4fbef263f636f907a28d78->leave($__internal_886be532dc5212862480e7c92ea64592bb13658b9e4fbef263f636f907a28d78_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_a91ffff6e504fe0d2ece552cfebb92c9d936f67a5244ddb78c14affead101f9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a91ffff6e504fe0d2ece552cfebb92c9d936f67a5244ddb78c14affead101f9c->enter($__internal_a91ffff6e504fe0d2ece552cfebb92c9d936f67a5244ddb78c14affead101f9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        echo "Welcome!";
        
        $__internal_a91ffff6e504fe0d2ece552cfebb92c9d936f67a5244ddb78c14affead101f9c->leave($__internal_a91ffff6e504fe0d2ece552cfebb92c9d936f67a5244ddb78c14affead101f9c_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d5a0e619b1e2e6ecea89c5b1dda4a9295fd1f8e39992a430f0caad5f6e7469ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5a0e619b1e2e6ecea89c5b1dda4a9295fd1f8e39992a430f0caad5f6e7469ed->enter($__internal_d5a0e619b1e2e6ecea89c5b1dda4a9295fd1f8e39992a430f0caad5f6e7469ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_d5a0e619b1e2e6ecea89c5b1dda4a9295fd1f8e39992a430f0caad5f6e7469ed->leave($__internal_d5a0e619b1e2e6ecea89c5b1dda4a9295fd1f8e39992a430f0caad5f6e7469ed_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_acbb05f01a37388b5a3fc6c5d704737c66ec9c24100330bcb28b46793cd61e60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acbb05f01a37388b5a3fc6c5d704737c66ec9c24100330bcb28b46793cd61e60->enter($__internal_acbb05f01a37388b5a3fc6c5d704737c66ec9c24100330bcb28b46793cd61e60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_acbb05f01a37388b5a3fc6c5d704737c66ec9c24100330bcb28b46793cd61e60->leave($__internal_acbb05f01a37388b5a3fc6c5d704737c66ec9c24100330bcb28b46793cd61e60_prof);

    }

    // line 18
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b6a4a186dd4985308a573bfa1c55262e74e81cf73447a9af210ab1e24fb0eb42 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6a4a186dd4985308a573bfa1c55262e74e81cf73447a9af210ab1e24fb0eb42->enter($__internal_b6a4a186dd4985308a573bfa1c55262e74e81cf73447a9af210ab1e24fb0eb42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "::base.html.twig"));

        
        $__internal_b6a4a186dd4985308a573bfa1c55262e74e81cf73447a9af210ab1e24fb0eb42->leave($__internal_b6a4a186dd4985308a573bfa1c55262e74e81cf73447a9af210ab1e24fb0eb42_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 18,  101 => 17,  90 => 6,  78 => 5,  69 => 19,  66 => 18,  64 => 17,  59 => 14,  50 => 12,  46 => 11,  38 => 7,  36 => 6,  32 => 5,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        <ul>
        {% for message in app.session.flashBag.get('messages') %}
            <li>{{ message }}</li>
        {% endfor %}


        </ul>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/base.html.twig");
    }
}
