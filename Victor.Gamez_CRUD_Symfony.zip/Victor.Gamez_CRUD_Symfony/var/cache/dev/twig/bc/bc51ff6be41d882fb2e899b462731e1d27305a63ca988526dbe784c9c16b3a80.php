<?php

/* Producto/create.html.twig */
class __TwigTemplate_2352602c14f0aaf61eb54347af5c301d3623e408ed9537d4fa19d449ca355abb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "Producto/create.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b26f24373d0ea9e67d429e9e0440712a6d2e96797959a61470984c7cda3b82f9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b26f24373d0ea9e67d429e9e0440712a6d2e96797959a61470984c7cda3b82f9->enter($__internal_b26f24373d0ea9e67d429e9e0440712a6d2e96797959a61470984c7cda3b82f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "Producto/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b26f24373d0ea9e67d429e9e0440712a6d2e96797959a61470984c7cda3b82f9->leave($__internal_b26f24373d0ea9e67d429e9e0440712a6d2e96797959a61470984c7cda3b82f9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_f0abd4749018ef962991ac0c8f646797abde13e35a12b96086b16ce39519b945 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f0abd4749018ef962991ac0c8f646797abde13e35a12b96086b16ce39519b945->enter($__internal_f0abd4749018ef962991ac0c8f646797abde13e35a12b96086b16ce39519b945_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/create.html.twig"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " Form";
        
        $__internal_f0abd4749018ef962991ac0c8f646797abde13e35a12b96086b16ce39519b945->leave($__internal_f0abd4749018ef962991ac0c8f646797abde13e35a12b96086b16ce39519b945_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_41fc75123e15533111f880b6480c1eb568e0605ec5225aff52e9dede4d6a6407 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41fc75123e15533111f880b6480c1eb568e0605ec5225aff52e9dede4d6a6407->enter($__internal_41fc75123e15533111f880b6480c1eb568e0605ec5225aff52e9dede4d6a6407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "Producto/create.html.twig"));

        // line 5
        echo "    <form action=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath((isset($context["action"]) ? $context["action"] : $this->getContext($context, "action")));
        echo "\" method=\"post\">

        name <input type=\"text\" name=\"name\" placeholder=\"nombre\"><br>
        descripcion <input type=\"text\" name=\"description\" placeholder=\"Descripcion\"> <br>
        precio<input type=\"number\" name=\"price\" placeholder=\"precio\"><br>


        <input type=\"submit\" value=\"Update Producto\">
    </form>
";
        
        $__internal_41fc75123e15533111f880b6480c1eb568e0605ec5225aff52e9dede4d6a6407->leave($__internal_41fc75123e15533111f880b6480c1eb568e0605ec5225aff52e9dede4d6a6407_prof);

    }

    public function getTemplateName()
    {
        return "Producto/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 5,  48 => 4,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}{{ parent() }} Form{% endblock %}
{% block body %}
    <form action=\"{{ path(action) }}\" method=\"post\">

        name <input type=\"text\" name=\"name\" placeholder=\"nombre\"><br>
        descripcion <input type=\"text\" name=\"description\" placeholder=\"Descripcion\"> <br>
        precio<input type=\"number\" name=\"price\" placeholder=\"precio\"><br>


        <input type=\"submit\" value=\"Update Producto\">
    </form>
{% endblock %}
", "Producto/create.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/app/Resources/views/Producto/create.html.twig");
    }
}
