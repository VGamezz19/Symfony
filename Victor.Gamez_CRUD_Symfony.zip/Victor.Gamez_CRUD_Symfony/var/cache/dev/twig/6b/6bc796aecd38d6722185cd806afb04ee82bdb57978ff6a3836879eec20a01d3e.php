<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_47878df8d32b525db0de6cb7dfc7a7fe7b0d89fb139999b1ab059ad33976d8ea extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eac50b8830c77fed4983118f37a3cd44e2725c90d28b5ef25a6640d43f5c520c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eac50b8830c77fed4983118f37a3cd44e2725c90d28b5ef25a6640d43f5c520c->enter($__internal_eac50b8830c77fed4983118f37a3cd44e2725c90d28b5ef25a6640d43f5c520c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eac50b8830c77fed4983118f37a3cd44e2725c90d28b5ef25a6640d43f5c520c->leave($__internal_eac50b8830c77fed4983118f37a3cd44e2725c90d28b5ef25a6640d43f5c520c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_410f0c889afb524d5fa9ce8c1e08f4228c0dc322d880fd96529550d2dcf95ca7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_410f0c889afb524d5fa9ce8c1e08f4228c0dc322d880fd96529550d2dcf95ca7->enter($__internal_410f0c889afb524d5fa9ce8c1e08f4228c0dc322d880fd96529550d2dcf95ca7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        
        $__internal_410f0c889afb524d5fa9ce8c1e08f4228c0dc322d880fd96529550d2dcf95ca7->leave($__internal_410f0c889afb524d5fa9ce8c1e08f4228c0dc322d880fd96529550d2dcf95ca7_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0d1bdf6409ba9fd4be8b482ab6369b0b3e964b3461b1447b2fae9d7077cc0876 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d1bdf6409ba9fd4be8b482ab6369b0b3e964b3461b1447b2fae9d7077cc0876->enter($__internal_0d1bdf6409ba9fd4be8b482ab6369b0b3e964b3461b1447b2fae9d7077cc0876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_0d1bdf6409ba9fd4be8b482ab6369b0b3e964b3461b1447b2fae9d7077cc0876->leave($__internal_0d1bdf6409ba9fd4be8b482ab6369b0b3e964b3461b1447b2fae9d7077cc0876_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_2b8ec19ac05836bc6790860acc33089c67f87be39ffc747e082274492d7e01d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b8ec19ac05836bc6790860acc33089c67f87be39ffc747e082274492d7e01d1->enter($__internal_2b8ec19ac05836bc6790860acc33089c67f87be39ffc747e082274492d7e01d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "@WebProfiler/Collector/router.html.twig"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_2b8ec19ac05836bc6790860acc33089c67f87be39ffc747e082274492d7e01d1->leave($__internal_2b8ec19ac05836bc6790860acc33089c67f87be39ffc747e082274492d7e01d1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/media/victor/VictorGamez/_DAW_2/M7/Symfony/Symfony/my_project_name/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
